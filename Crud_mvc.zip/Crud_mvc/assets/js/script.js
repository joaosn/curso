function adicionar(e) {
	e.preventDefault();
	$('#modal').modal('show');
		

}
 
	 
