<?php  
define("ENVIRONMENT", "development"); // servidor interno;
//define("ENVIRONMENT", "production"); // servidor externo;
?>